/*  
    Copyright (C) 2012 G. Michael Barnes
 
    The file Stage.cs is part of AGXNASKv4.

    AGXNASKv4 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace AGXNASK {

    /// <summary>
    /// A non-playing character that moves.  Override the inherited Update(GameTime)
    /// to implement a movement (strategy?) algorithm.
    /// Distribution NPAgent moves along an "exploration" path that is created by
    /// method makePath().  The exploration path is traversed in a reverse path loop.
    /// Paths can also be specified in text files of Vector3 values.  
    /// In this case create the Path with a string argument for the file's address.
    /// 
    /// 2/14/2012 last changed
    /// </summary>

    public class NPAgent : Agent {
        private NavNode nextGoal;
        private Path regularPath;
        private Path treasurePath;
        private Path currentPath;

        private int snapDistance = 20;
        private int turnCount = 0;

        /// <summary>
        /// Create a NPC. 
        /// AGXNASK distribution has npAgent move following a Path.
        /// </summary>
        /// <param name="theStage"> the world</param>
        /// <param name="label"> name of </param>
        /// <param name="pos"> initial position </param>
        /// <param name="orientAxis"> initial rotation axis</param>
        /// <param name="radians"> initial rotation</param>
        /// <param name="meshFile"> Direct X *.x Model in Contents directory </param>

        public NPAgent(Stage theStage, string label, Vector3 pos, 
                       Vector3 orientAxis, float radians, string meshFile, 
                       List<NavNode> regularPathNodes, List<NavNode> treasurePathNodes)

            : base(theStage, label, pos, orientAxis, radians, meshFile) {  

            first.Name = "npFirst";
            follow.Name = "npFollow";
            above.Name = "npAbove";
            
            treasurePath = new Path(stage, treasurePathNodes, Path.PathType.SINGLE);
            regularPath = new Path(stage, regularPathNodes, Path.PathType.LOOP);

            // initially NPAgent follows his default path
            currentPath = regularPath;
            
            // set the first goal
            nextGoal = currentPath.NextNode;

            // turn to face this goal 
            agentObject.turnToFace(nextGoal.Translation);

            stage.Components.Add(currentPath);
            // IsCollidable = true;  // have NPAgent test collisions
        }

        public void switchPath() {
            if (IsDone()) {
               
            }

            if (currentPath == treasurePath) 
                currentPath = regularPath;
            else 
                currentPath = treasurePath;

            nextGoal = currentPath.CurrentNode;
            agentObject.turnToFace(nextGoal.Translation);
        }

        public bool IsDone() {
            for (int i = 0; i < treasurePath.Nodes.Count; ++i) {
                if (treasurePath.Nodes[i].IsActive == true) {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// A very simple limited random walk.  Repeatedly moves skipSteps forward then
        /// randomly decides how to turn (left, right, or not to turn).  Does not move
        /// very well -- its just an example...
        /// </summary>
        public override void Update(GameTime gameTime) {
            stage.setInfo(15,
               string.Format("npAvatar:  Location ({0:f0},{1:f0},{2:f0})  Looking at ({3:f2},{4:f2},{5:f2})",
                  agentObject.Translation.X, 
                  agentObject.Translation.Y, 
                  agentObject.Translation.Z,

                  agentObject.Forward.X, 
                  agentObject.Forward.Y, 
                  agentObject.Forward.Z));

            stage.setInfo(16,
               string.Format("nextGoal:  ({0:f0},{1:f0},{2:f0})", nextGoal.Translation.X, nextGoal.Translation.Y, nextGoal.Translation.Z));

            // See if at or close to nextGoal, distance measured in the flat XZ plane
            float distance = Vector3.Distance(
                new Vector3(nextGoal.Translation.X, 0, nextGoal.Translation.Z),
                new Vector3(agentObject.Translation.X, 0, agentObject.Translation.Z));

            if (distance <= snapDistance && nextGoal.IsActive) {
                System.Diagnostics.Debug.WriteLine("Got treasure?: " + nextGoal.Translation.ToString());
                stage.setInfo(17, string.Format("distance to goal = {0,5:f2}", distance));

                nextGoal.IsActive = false;
                nextGoal = currentPath.NextNode;
                agentObject.turnToFace(nextGoal.Translation);

                if (currentPath.Done) {
                    stage.setInfo(18, "path traversal is done");
                }
                else {
                    turnCount++;
                    stage.setInfo(18, string.Format("turnToFace count = {0}", turnCount));
                }
            }

            base.Update(gameTime);  // Agent's Update();
        }
    }
}