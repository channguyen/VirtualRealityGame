/*  
    Copyright (C) 2012 G. Michael Barnes
 
    The file Scene.cs is part of AGXNASKv4.

    AGXNASKv4 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

using System;
using Microsoft.Xna.Framework;
using System.Collections.Generic;


namespace AGXNASK {
    /// <summary>
    /// Scene.cs  the "main class" for AGXNASK
    /// 
    /// AGXNASK is a starter kit for Comp 565 assignments using XNA Game Studio 4.0
    /// and Visual Studio 2010.
    /// 
    /// Scene declares and initializes program specific entities and user interaction.
    /// 
    /// See AGXNASKv4-doc.pdf file for class diagram and usage information. 
    /// 
    /// </summary>
    public class Scene : Stage {

        public Scene() {
            // default
        }

        /// <summary>
        /// Set GraphicDevice display and rendering BasicEffect effect.  
        /// Create SpriteBatch, font, and font positions.
        /// Creates the traceViewport to display information and the sceneViewport
        /// to render the environment.
        /// Create and add all DrawableGameComponents and Cameras.
        /// </summary>
        protected override void LoadContent() {
            base.LoadContent();  // create the Scene entities -- Inspector.

            // create a temple
            Model3D m3d = new Model3D(this, "temple", "templeV3");
            m3d.IsCollidable = true;  // must be set before addObject(...) and Model3D doesn't set it
            m3d.addObject(new Vector3(340 * spacing, terrain.surfaceHeight(340, 340), 340 * spacing), new Vector3(0, 1, 0), 0.79f);
            Components.Add(m3d);

            Model3D another = new Model3D(this, "Example", "Example");
            another.IsCollidable = true;  // must be set before addObject(...) and Model3D doesn't set it
            another.addObject(new Vector3(320 * spacing, terrain.surfaceHeight(320, 320), 320 * spacing), new Vector3(0, 1, 0), 1.0f);
            Components.Add(another);

            Model3D treasure1 = new Model3D(this, "Treasure1", "Treasure100x100x100Blue");
            treasure1.IsCollidable = true;
            treasure1.addObject(new Vector3(296 * spacing, terrain.surfaceHeight(296, 450), 450 * spacing), new Vector3(0, 1, 0), 1.0f);
            Components.Add(treasure1);

            Model3D treasure2 = new Model3D(this, "Treasure2", "Treasure100x100x100Purple");
            treasure2.IsCollidable = true;
            treasure2.addObject(new Vector3(340 * spacing, terrain.surfaceHeight(340, 325), 325 * spacing), new Vector3(0, 1, 0), 1.0f);
            Components.Add(treasure2);


            Model3D treasure3 = new Model3D(this, "Treasure3", "Treasure100x100x100Yellow");
            treasure3.IsCollidable = true;
            treasure3.addObject(new Vector3(320 * spacing, terrain.surfaceHeight(320, 399), 399 * spacing), new Vector3(0, 1, 0), 1.0f);
            Components.Add(treasure3);

            Model3D treasure4 = new Model3D(this, "Treasure4", "Treasure200x200x200Black");
            treasure4.IsCollidable = true;
            treasure4.addObject(new Vector3(306 * spacing, terrain.surfaceHeight(306, 438), 438 * spacing), new Vector3(0, 1, 0), 1.0f);
            Components.Add(treasure4);

            // create walls for obstacle avoidance or path finding algorithms
            Wall wall = new Wall(this, "wall", "100x100x100Brick");
            Components.Add(wall);

            // create a Pack of dogs
            Pack pack = new Pack(this, "dog", "dogV3");
            Components.Add(pack);

            Random random = new Random();
            for (int x = -9; x < 10; x += 6) {
                for (int z = -3; z < 4; z += 6) {
                    float scale = (float) (0.5 + random.NextDouble());
                    float xPos = (384 + x) * spacing;
                    float zPos = (384 + z) * spacing;
                    pack.addObject(
                        new Vector3(xPos, terrain.surfaceHeight((int) xPos / spacing, (int) zPos / spacing), zPos),
                        new Vector3(0, 1, 0), 0.0f,
                        new Vector3(scale, scale, scale));
                }
            }

            // create some clouds
            Cloud cloud = new Cloud(this, "cloud", "cloudV3");
            Components.Add(cloud);
            // add 9 cloud instances
            for (int x = range / 4; x < range; x += (range / 4)) {
                for (int z = range / 4; z < range; z += (range / 4)) {
                    cloud.addObject(
                        new Vector3(x * spacing, terrain.surfaceHeight(x, z) + 2000, z * spacing),
                        new Vector3(0, 1, 0), 0.0f,
                        new Vector3(random.Next(3) + 1, random.Next(3) + 1, random.Next(3) + 1));
                }
            }

            // We load player and npAgent in Scence so that they can be initialized to treasure goals

            List<NavNode> treasurePath = makeTreasurePathNodes();

            player = new Player(
                this,
                "Chaser",
                new Vector3(17093, 100, 1293), // close to hill to test terrain following
                new Vector3(0, 1, 0),         // face looking diagonally across stage 
                0.80f,
                "redAvatarV3",
                treasurePath);

            // add a player character
            Components.Add(player);

            npAgent = new NPAgent(
                 this,
                "Evader",
                 new Vector3(400 * spacing, terrain.surfaceHeight(400, 400), 400 * spacing),
                 new Vector3(0, 1, 0),
                 0.0f,
                 "magentaAvatarV3",
                 treasurePath,
                 makeTreasurePathNodes()); 

            // add a non-player character
            Components.Add(npAgent);
            nextCamera();
        }

        protected override void Update(GameTime gameTime) {
            base.Update(gameTime);
        }

        private List<NavNode> makeTreasurePathNodes() {
            List<NavNode> path = new List<NavNode>();
            path.Add(new NavNode(new Vector3(296 * spacing, terrain.surfaceHeight(296, 450), 450 * spacing), NavNode.NavNodeEnum.PATH));
            path.Add(new NavNode(new Vector3(340 * spacing, terrain.surfaceHeight(340, 325), 325 * spacing), NavNode.NavNodeEnum.PATH));
            path.Add(new NavNode(new Vector3(320 * spacing, terrain.surfaceHeight(320, 399), 399 * spacing), NavNode.NavNodeEnum.PATH));
            path.Add(new NavNode(new Vector3(306 * spacing, terrain.surfaceHeight(306, 438), 438 * spacing), NavNode.NavNodeEnum.PATH));
            return path;
        }

        private List<NavNode> makeRegularPathNodes() {
            List<NavNode> path = new List<NavNode>();
            int spacing =  terrain.Spacing;

            // make a simple path, show how to set the type of the NavNode outside of construction.
            NavNode n;
            n = new NavNode(new Vector3(505 * spacing, terrain.surfaceHeight(505, 505), 505 * spacing));
            n.Navigatable = NavNode.NavNodeEnum.PATH;
            path.Add(n);

            n = new NavNode(new Vector3(500 * spacing, terrain.surfaceHeight(500, 500), 500 * spacing));
            n.Navigatable = NavNode.NavNodeEnum.VERTEX;
            path.Add(n);

            path.Add(new NavNode(new Vector3(495 * spacing, terrain.surfaceHeight(495, 495), 495 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            path.Add(new NavNode(new Vector3(495 * spacing, terrain.surfaceHeight(495, 505), 505 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            path.Add(new NavNode(new Vector3(100 * spacing, terrain.surfaceHeight(100, 500), 500 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            path.Add(new NavNode(new Vector3(100 * spacing, terrain.surfaceHeight(100, 100), 100 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            path.Add(new NavNode(new Vector3(500 * spacing, terrain.surfaceHeight(500, 100), 100 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            n = new NavNode(new Vector3(500 * spacing, terrain.surfaceHeight(500, 495), 495 * spacing));
            n.Navigatable = NavNode.NavNodeEnum.A_STAR;
            path.Add(n);

            path.Add(new NavNode(new Vector3(495 * spacing, terrain.surfaceHeight(495, 105), 105 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            path.Add(new NavNode(new Vector3(105 * spacing, terrain.surfaceHeight(105, 105), 105 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            path.Add(new NavNode(new Vector3(105 * spacing, terrain.surfaceHeight(105, 495), 495 * spacing),
                     NavNode.NavNodeEnum.WAYPOINT));

            return path;
        }

        static void Main(string[] args) {
            using (Scene stage = new Scene()) {  
                stage.Run(); 
            }
        }
    }
}